package com.java.cms;

public enum WalletSource {
	PAYTM, CREDIT_CARD, DEBIT_CARD
}
