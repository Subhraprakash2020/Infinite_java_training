package com.java.rms;

public interface VenderDAO {

}
