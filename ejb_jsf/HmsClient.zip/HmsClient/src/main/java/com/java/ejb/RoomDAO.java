package com.java.ejb;

import java.sql.SQLException;
import java.util.List;

public interface RoomDAO {
	List<Room> showRoomType() throws ClassNotFoundException, SQLException;
	List<Room> showRoomNo() throws ClassNotFoundException, SQLException;
}
